package com.frauddetection.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;
    private final AdminInterceptor adminInterceptor;

    public WebConfig(AuthInterceptor authInterceptor,
                     AdminInterceptor adminInterceptor) {
        this.authInterceptor = authInterceptor;
        this.adminInterceptor = adminInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        registry.addInterceptor(authInterceptor)
                .addPathPatterns(
                        "/dashboard",
                        "/transaction",
                        "/transactions",
                        "/profile",
                        "/test-location"
                )
                .excludePathPatterns(
                        "/",
                        "/login",
                        "/signup"
                );

        registry.addInterceptor(adminInterceptor)
                .addPathPatterns(
                        "/admin",
                        "/reports",
                        "/transaction/delete/**"
                );
    }
}