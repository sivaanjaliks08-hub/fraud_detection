package com.frauddetection.controller;

import com.frauddetection.model.User;
import com.frauddetection.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AdminController {

    private final UserRepository userRepository;

    public AdminController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/admin")
    public String adminPage(
            HttpSession session,
            Model model) {

        User loggedInUser =
                (User) session.getAttribute("loggedInUser");

        if (loggedInUser == null) {
            return "redirect:/login";
        }

        if (!"ADMIN".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/dashboard";
        }

        List<User> users = userRepository.findAll();

        model.addAttribute("users", users);
        model.addAttribute("user", loggedInUser);

        return "admin";
    }
}