package com.frauddetection.controller;

import com.frauddetection.service.LocationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @GetMapping("/test-location")
    public String testLocation(
            @RequestParam(required = false) String ip,
            Model model) {

        if (ip != null && !ip.trim().isEmpty()) {

            String location =
                    locationService.getLocationFromIp(ip);

            model.addAttribute("location", location);
            model.addAttribute("ip", ip);
        }

        return "location-test";
    }
}