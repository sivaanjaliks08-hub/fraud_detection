package com.frauddetection.controller;

import com.frauddetection.model.User;
import com.frauddetection.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            Model model) {

        User user =
                userService.authenticateUser(
                        username,
                        password
                );

        if (user == null) {

            model.addAttribute(
                    "error",
                    "Invalid username or password."
            );

            return "login";
        }

        session.setAttribute("loggedInUser", user);

        return "redirect:/dashboard";
    }
}