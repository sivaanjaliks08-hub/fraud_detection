package com.frauddetection.controller;

import com.frauddetection.service.TransactionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ReportController {

    private final TransactionService transactionService;

    public ReportController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping("/reports")
    public String reports(Model model) {

        model.addAttribute(
                "totalTransactions",
                transactionService.getTransactionCount()
        );

        model.addAttribute(
                "fraudTransactions",
                transactionService.getFraudCount()
        );

        model.addAttribute(
                "safeTransactions",
                transactionService.getSafeCount()
        );

        model.addAttribute(
                "totalAmount",
                transactionService.getTotalAmount()
        );

        model.addAttribute(
                "fraudAmount",
                transactionService.getTotalFraudAmount()
        );

        model.addAttribute(
                "fraudPercentage",
                transactionService.getFraudPercentage()
        );

        model.addAttribute(
                "highestTransaction",
                transactionService.getHighestTransactionAmount()
        );

        model.addAttribute(
                "averageTransaction",
                transactionService.getAverageTransactionAmount()
        );

        return "reports";
    }
}