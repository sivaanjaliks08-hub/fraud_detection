package com.frauddetection.controller;

import com.frauddetection.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SignupController {

    private final UserService userService;

    public SignupController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    @PostMapping("/signup")
    public String registerUser(
            @RequestParam String username,
            @RequestParam String password,
            Model model) {

        boolean registered =
                userService.registerUser(username, password);

        if (!registered) {

            model.addAttribute(
                    "error",
                    "Username already exists."
            );

            return "signup";
        }

        return "redirect:/login";
    }
}