package com.frauddetection.controller;

import com.frauddetection.model.User;
import jakarta.servlet.http.HttpSession;
import com.frauddetection.model.Transaction;
import com.frauddetection.service.TransactionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.BindingResult;
import jakarta.validation.Valid;

@Controller
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // Show transaction form
    @GetMapping("/transaction")
    public String showTransactionForm(Model model) {

        model.addAttribute("transaction", new Transaction());

        return "transaction";
    }

    // Process transaction
    @PostMapping("/transaction")
    public String processTransaction(
            @Valid @ModelAttribute Transaction transaction,
            org.springframework.validation.BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "transaction";
        }

        Transaction analyzedTransaction = transactionService.saveTransaction(transaction);
        model.addAttribute("transaction", analyzedTransaction);

        return "transaction-result";
    }

    @GetMapping("/transactions")
    public String viewTransactions(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            HttpSession session,
            Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        model.addAttribute("user", user);

        if (keyword != null && !keyword.trim().isEmpty()
                && status != null && !status.trim().isEmpty()) {

            boolean fraud = status.equals("fraud");

            model.addAttribute(
                    "transactions",
                    transactionService.searchTransactionsByStatus(
                            keyword,
                            fraud
                    )
            );

        } else if (keyword != null && !keyword.trim().isEmpty()) {

            model.addAttribute(
                    "transactions",
                    transactionService.searchTransactions(keyword)
            );

        } else if (status != null && status.equals("fraud")) {

            model.addAttribute(
                    "transactions",
                    transactionService.getFraudTransactions()
            );

        } else if (status != null && status.equals("safe")) {

            model.addAttribute(
                    "transactions",
                    transactionService.getSafeTransactions()
            );

        } else {

            model.addAttribute(
                    "transactions",
                    transactionService.getAllTransactions()
            );
        }

        model.addAttribute("keyword", keyword);
        model.addAttribute("status", status);

        return "transactions";
    }

    @GetMapping("/transaction/delete/{id}")
    public String deleteTransaction(@PathVariable Long id) {

        transactionService.deleteTransaction(id);

        return "redirect:/transactions";
    }
}