package com.frauddetection.controller;

import com.frauddetection.service.TransactionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.frauddetection.model.User;
import jakarta.servlet.http.HttpSession;

@Controller
public class WebController {

    private final TransactionService transactionService;

    public WebController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // Home Page
    @GetMapping("/")
    public String home() {
        return "Welcome";
    }

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard(
            Model model,
            HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");

        model.addAttribute("user", user);

        // your existing dashboard code continues here...

        // Transaction statistics
        model.addAttribute(
                "totalTransactions",
                transactionService.getTransactionCount()
        );

        model.addAttribute(
                "fraudTransactions",
                transactionService.getFraudCount()
        );

        model.addAttribute(
                "safeTransactions",
                transactionService.getSafeCount()
        );

        // Amount statistics
        model.addAttribute(
                "totalAmount",
                transactionService.getTotalAmount()
        );

        model.addAttribute(
                "fraudAmount",
                transactionService.getTotalFraudAmount()
        );

        model.addAttribute(
                "highestTransaction",
                transactionService.getHighestTransactionAmount()
        );

        model.addAttribute(
                "averageTransaction",
                transactionService.getAverageTransactionAmount()
        );

        // Fraud percentage
        model.addAttribute(
                "fraudPercentage",
                transactionService.getFraudPercentage()
        );

        // Recent transactions
        model.addAttribute(
                "recentTransactions",
                transactionService.getAllTransactions()
                        .stream()
                        .sorted((a, b) -> Long.compare(b.getId(), a.getId()))
                        .limit(5)
                        .toList()
        );

        return "dashboard";
    }
}