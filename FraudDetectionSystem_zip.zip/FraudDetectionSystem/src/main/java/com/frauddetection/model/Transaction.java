package com.frauddetection.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String senderName;

    private String receiverName;

    @Pattern(
            regexp = "^[0-9]{11}$",
            message = "Sender account number must contain exactly 11 digits."
    )
    private String senderAccount;

    @Pattern(
            regexp = "^[0-9]{11}$",
            message = "Receiver account number must contain exactly 11 digits."
    )
    private String receiverAccount;

    private double amount;

    private String date;

    private String time;

    private String ipAddress;

    private String location;

    private boolean fraud;

    private int riskScore;

    private String fraudReason;


    // Default Constructor
    public Transaction() {
    }


    // Constructor
    public Transaction(String senderName, String receiverName,
                       String senderAccount, String receiverAccount,
                       double amount, String date, String time,
                       String ipAddress, String location,
                       boolean fraud, int riskScore,
                       String fraudReason) {

        this.senderName = senderName;
        this.receiverName = receiverName;
        this.senderAccount = senderAccount;
        this.receiverAccount = receiverAccount;
        this.amount = amount;
        this.date = date;
        this.time = time;
        this.ipAddress = ipAddress;
        this.location = location;
        this.fraud = fraud;
        this.riskScore = riskScore;
        this.fraudReason = fraudReason;
    }


    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getSenderAccount() {
        return senderAccount;
    }

    public void setSenderAccount(String senderAccount) {
        this.senderAccount = senderAccount;
    }

    public String getReceiverAccount() {
        return receiverAccount;
    }

    public void setReceiverAccount(String receiverAccount) {
        this.receiverAccount = receiverAccount;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isFraud() {
        return fraud;
    }

    public void setFraud(boolean fraud) {
        this.fraud = fraud;
    }

    public int getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(int riskScore) {
        this.riskScore = riskScore;
    }

    public String getFraudReason() {
        return fraudReason;
    }

    public void setFraudReason(String fraudReason) {
        this.fraudReason = fraudReason;
    }

    public String getFormattedTime() {
        if (time == null || time.isBlank()) {
            return "";
        }

        try {
            java.time.LocalTime localTime =
                    java.time.LocalTime.parse(time);

            return localTime.format(
                    java.time.format.DateTimeFormatter.ofPattern("hh:mm a")
            );
        } catch (Exception e) {
            return time;
        }
    }
    public String getFormattedDate() {
        if (date == null || date.isBlank()) {
            return "";
        }

        try {
            java.time.LocalDate localDate =
                    java.time.LocalDate.parse(date);

            return localDate.format(
                    java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy")
            );
        } catch (Exception e) {
            return date;
        }
    }
}