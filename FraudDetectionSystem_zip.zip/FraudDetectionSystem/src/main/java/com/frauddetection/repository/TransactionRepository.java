package com.frauddetection.repository;

import com.frauddetection.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    long countByFraudTrue();

    long countByFraudFalse();

    List<Transaction> findBySenderNameContainingIgnoreCaseOrReceiverNameContainingIgnoreCase(
            String senderName,
            String receiverName
    );

    List<Transaction> findByFraudTrue();

    List<Transaction> findByFraudFalse();
    List<Transaction> findBySenderNameContainingIgnoreCaseAndFraud(
            String senderName,
            boolean fraud
    );

    List<Transaction> findByReceiverNameContainingIgnoreCaseAndFraud(
            String receiverName,
            boolean fraud
    );
    List<Transaction> findBySenderAccount(String senderAccount);
}