package com.frauddetection.service;

import com.frauddetection.model.Transaction;
import com.frauddetection.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class FraudDetectionService {

    private static final double FRAUD_AMOUNT_LIMIT = 50000.0;

    private static final int RAPID_TRANSACTION_RISK = 30;

    private static final int RAPID_TRANSACTION_MINUTES = 5;

    private static final int SUSPICIOUS_LOCATION_RISK = 40;

    private static final int LOCATION_CHANGE_MINUTES = 30;

    private final TransactionRepository transactionRepository;

    public FraudDetectionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public Transaction analyzeTransaction(Transaction transaction) {

        int riskScore = 0;
        StringBuilder reasons = new StringBuilder();

        /*
         * RULE 1:
         * Transaction amount greater than ₹50,000
         */
        if (transaction.getAmount() > FRAUD_AMOUNT_LIMIT) {

            riskScore += 100;

            reasons.append("Transaction amount exceeds ₹50,000");

        }


        /*
         * RULE 2:
         * Multiple transactions from the same sender
         * within 5 minutes
         */
        if (isRapidTransaction(transaction)) {

            riskScore += RAPID_TRANSACTION_RISK;

            if (reasons.length() > 0) {
                reasons.append("; ");
            }

            reasons.append(
                    "Multiple transactions detected from the same sender within 5 minutes"
            );
        }

        /*
         * RULE 3:
         * Same sender using a different location
         * within 30 minutes
         */
        if (hasLocationChanged(transaction)) {

            riskScore += SUSPICIOUS_LOCATION_RISK;

            if (reasons.length() > 0) {
                reasons.append("; ");
            }

            reasons.append(
                    "Same sender used a different location within 30 minutes"
            );
        }

        /*
         * RULE 4:
         * Suspicious location detection
         */
        if (isSuspiciousLocation(transaction)) {

            riskScore += SUSPICIOUS_LOCATION_RISK;

            if (reasons.length() > 0) {
                reasons.append("; ");
            }

            reasons.append(
                    "Transaction originated from a suspicious location"
            );
        }


        /*
         * FINAL FRAUD DECISION
         */
        if (riskScore >= 50) {

            transaction.setFraud(true);

            transaction.setRiskScore(riskScore);

            transaction.setFraudReason(reasons.toString());

        } else {

            transaction.setFraud(false);

            transaction.setRiskScore(riskScore);

            if (reasons.length() == 0) {

                transaction.setFraudReason(
                        "Transaction passed the current fraud detection rules"
                );

            } else {

                transaction.setFraudReason(
                        reasons.toString()
                );
            }
        }

        return transaction;
    }


    /*
     * Checks whether the sender has made
     * another transaction within the last 5 minutes.
     */
    private boolean isRapidTransaction(Transaction transaction) {

        String senderAccount = transaction.getSenderAccount();

        if (senderAccount == null || senderAccount.trim().isEmpty()) {
            return false;
        }

        List<Transaction> previousTransactions =
                transactionRepository.findBySenderAccount(senderAccount);

        if (previousTransactions.isEmpty()) {
            return false;
        }

        try {

            LocalDateTime currentDateTime =
                    parseDateTime(transaction.getDate(), transaction.getTime());

            for (Transaction previous : previousTransactions) {

                if (previous.getDate() == null ||
                        previous.getTime() == null) {
                    continue;
                }

                LocalDateTime previousDateTime =
                        parseDateTime(
                                previous.getDate(),
                                previous.getTime()
                        );

                long secondsDifference =
                        Math.abs(
                                java.time.Duration.between(
                                        previousDateTime,
                                        currentDateTime
                                ).getSeconds()
                        );

                if (secondsDifference > 0 &&
                        secondsDifference <= RAPID_TRANSACTION_MINUTES * 60) {

                    return true;
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "Rapid transaction detection error: "
                            + e.getMessage()
            );
        }

        return false;
    }


    /*
     * Converts the date and time stored in the Transaction
     * object into LocalDateTime.
     */
    private LocalDateTime parseDateTime(
            String date,
            String time) {

        LocalTime localTime =
                LocalTime.parse(time);

        return LocalDateTime.of(
                java.time.LocalDate.parse(date),
                localTime
        );
    }
    /*
     * Checks whether the transaction location
     * should be considered suspicious.
     */
    private boolean isSuspiciousLocation(Transaction transaction) {

        String location = transaction.getLocation();

        if (location == null || location.trim().isEmpty()) {
            return false;
        }

        /*
         * For the current project, locations containing
         * these values are treated as suspicious.
         *
         * This is a demonstration rule and can be
         * replaced later with a database/API-based
         * location risk system.
         */
        String lowerLocation = location.toLowerCase();

        return lowerLocation.contains("unknown")
                || lowerLocation.contains("unavailable")
                || lowerLocation.contains("russia")
                || lowerLocation.contains("north korea");
    }
    private boolean hasLocationChanged(Transaction transaction) {

        String senderAccount = transaction.getSenderAccount();
        String currentLocation = transaction.getLocation();

        if (senderAccount == null || currentLocation == null
                || senderAccount.trim().isEmpty()
                || currentLocation.trim().isEmpty()
                || currentLocation.equalsIgnoreCase("Location unavailable")) {
            return false;
        }

        List<Transaction> previousTransactions =
                transactionRepository.findBySenderAccount(senderAccount);

        if (previousTransactions.isEmpty()) {
            return false;
        }

        try {

            LocalDateTime currentDateTime =
                    parseDateTime(transaction.getDate(), transaction.getTime());

            for (Transaction previous : previousTransactions) {

                if (previous.getDate() == null ||
                        previous.getTime() == null ||
                        previous.getLocation() == null) {
                    continue;
                }

                LocalDateTime previousDateTime =
                        parseDateTime(
                                previous.getDate(),
                                previous.getTime()
                        );

                long minutesDifference =
                        Math.abs(
                                java.time.Duration.between(
                                        previousDateTime,
                                        currentDateTime
                                ).toMinutes()
                        );

                if (minutesDifference <= LOCATION_CHANGE_MINUTES
                        && !currentLocation.equalsIgnoreCase(
                        previous.getLocation())) {

                    return true;
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "Location change detection error: "
                            + e.getMessage()
            );
        }

        return false;
    }
}