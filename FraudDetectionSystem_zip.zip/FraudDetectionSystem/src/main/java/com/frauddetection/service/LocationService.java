package com.frauddetection.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class LocationService {

    private final RestTemplate restTemplate = new RestTemplate();

    public String getLocationFromIp(String ipAddress) {

        try {

            String url = "https://ipinfo.io/" + ipAddress + "/json";

            Map<String, Object> response =
                    restTemplate.getForObject(url, Map.class);

            System.out.println("IPINFO RESPONSE: " + response);

            if (response != null) {

                String city = String.valueOf(response.get("city"));
                String region = String.valueOf(response.get("region"));
                String country = String.valueOf(response.get("country"));

                if (!city.equals("null")
                        && !region.equals("null")
                        && !country.equals("null")) {

                    return city + ", " + region + ", " + country;
                }
            }

            System.out.println("IPinfo could not identify the location.");

        } catch (Exception e) {

            System.out.println(
                    "Location detection error: " + e.getMessage()
            );
        }

        return "Location unavailable";
    }
}