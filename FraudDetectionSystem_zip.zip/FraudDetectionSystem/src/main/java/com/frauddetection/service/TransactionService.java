package com.frauddetection.service;

import com.frauddetection.model.Transaction;
import com.frauddetection.service.LocationService;
import com.frauddetection.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final FraudDetectionService fraudDetectionService;
    private final LocationService locationService;

    public TransactionService(
            TransactionRepository transactionRepository,
            FraudDetectionService fraudDetectionService,
            LocationService locationService) {

        this.transactionRepository = transactionRepository;
        this.fraudDetectionService = fraudDetectionService;
        this.locationService = locationService;
    }

    public Transaction saveTransaction(Transaction transaction) {

        if (transaction.getIpAddress() != null
                && !transaction.getIpAddress().trim().isEmpty()) {

            String location =
                    locationService.getLocationFromIp(
                            transaction.getIpAddress()
                    );

            transaction.setLocation(location);
        }

        transaction =
                fraudDetectionService.analyzeTransaction(transaction);

        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }
    public List<Transaction> searchTransactions(String keyword) {

        return transactionRepository
                .findBySenderNameContainingIgnoreCaseOrReceiverNameContainingIgnoreCase(
                        keyword,
                        keyword
                );
    }
    public List<Transaction> getFraudTransactions() {

        return transactionRepository.findByFraudTrue();
    }

    public List<Transaction> getSafeTransactions() {

        return transactionRepository.findByFraudFalse();
    }

    public List<Transaction> searchTransactionsByStatus(
            String keyword,
            boolean fraud) {

        List<Transaction> senderResults =
                transactionRepository
                        .findBySenderNameContainingIgnoreCaseAndFraud(
                                keyword,
                                fraud
                        );

        List<Transaction> receiverResults =
                transactionRepository
                        .findByReceiverNameContainingIgnoreCaseAndFraud(
                                keyword,
                                fraud
                        );

        senderResults.addAll(receiverResults);

        return senderResults.stream()
                .distinct()
                .toList();
    }

    public Transaction getTransactionById(Long id) {
        return transactionRepository.findById(id).orElse(null);
    }

    public void deleteTransaction(Long id) {
        transactionRepository.deleteById(id);
    }

    public long getTransactionCount() {
        return transactionRepository.count();
    }

    public long getFraudCount() {
        return transactionRepository.countByFraudTrue();
    }

    public long getSafeCount() {
        return transactionRepository.countByFraudFalse();
    }

    public double getTotalAmount() {
        return transactionRepository.findAll()
                .stream()
                .mapToDouble(Transaction::getAmount)
                .sum();
    }
    public double getTotalFraudAmount() {

        return transactionRepository.findAll()
                .stream()
                .filter(Transaction::isFraud)
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getHighestTransactionAmount() {

        return transactionRepository.findAll()
                .stream()
                .mapToDouble(Transaction::getAmount)
                .max()
                .orElse(0);
    }

    public double getAverageTransactionAmount() {

        return transactionRepository.findAll()
                .stream()
                .mapToDouble(Transaction::getAmount)
                .average()
                .orElse(0);
    }

    public double getFraudPercentage() {

        long total = transactionRepository.count();

        if (total == 0) {
            return 0;
        }

        long fraud = transactionRepository.countByFraudTrue();

        return (fraud * 100.0) / total;
    }
}