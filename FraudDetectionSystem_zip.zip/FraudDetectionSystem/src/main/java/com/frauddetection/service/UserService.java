package com.frauddetection.service;

import com.frauddetection.model.User;
import com.frauddetection.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean registerUser(String username, String password) {

        if (userRepository.findByUsername(username).isPresent()) {
            return false;
        }

        String encryptedPassword =
                passwordEncoder.encode(password);

        User user = new User(
                username,
                encryptedPassword,
                "USER"
        );

        userRepository.save(user);

        return true;
    }

    public User authenticateUser(
            String username,
            String password) {

        return userRepository
                .findByUsername(username)
                .filter(user ->
                        passwordEncoder.matches(
                                password,
                                user.getPassword()
                        )
                )
                .orElse(null);
    }
}